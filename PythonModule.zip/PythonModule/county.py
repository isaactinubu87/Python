import mymodule as my
a = my.person1["Country"]
print(a)
