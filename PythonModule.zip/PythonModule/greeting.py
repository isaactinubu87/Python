import mymodule as my
my.greetings("Oluwadare")
