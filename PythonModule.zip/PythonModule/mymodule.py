def greetings(name):
    print("Hello, " + name)

person1 = {
    "name": "John",
    "age": 36,
    "Country": "Norway"
    }



